﻿
$(function () {
    
    $("#tabs").tabs();

    
});

